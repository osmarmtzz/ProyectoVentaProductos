
setTimeout(function() {
  document.querySelector('.loader-wrapper').style.display = 'none';
  document.getElementById('content').style.display = 'block';
}, 1500);